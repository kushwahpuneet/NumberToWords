package com.java.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.service.NumberWordConverterService;;

public class NumberWordConverterTest extends SpringBootTestBase {
	
	@Autowired 
	private  NumberWordConverterService numberWordConverterTest;

	 
	@Test
	public void testDollarsAndCentthenReturnWords() {
	    String expectedResult
	     = "NINE HUNDRED TWENTY FOUR DOLLERS AND SIX CENTS";
	    
	    assertEquals( expectedResult, 
	    		numberWordConverterTest.getMoneyIntoWords("924.6"));
	}

	

	@Test
	public void testZeroDollarsthenReturnEmptyString() {
	    assertEquals("", numberWordConverterTest.getMoneyIntoWords("0"));
	}

		  
	@Test
	public void testNoDollarsAndOneCentReturnCentSingular() {
	    assertEquals(
	      "ONE CENTS", 
	      numberWordConverterTest.getMoneyIntoWords("0.01"));
	}
}
