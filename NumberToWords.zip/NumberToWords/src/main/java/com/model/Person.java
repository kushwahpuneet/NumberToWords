package com.model;

public class Person {
 
	private String name;
	private String money;
	 

	public Person() {
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMoney() {
		return money;
	}


	public void setMoney(String money) {
		this.money = money;
	}

	 
}
